<?php 
  include 'config.php';
  if (isset($_POST['Book'])) {
     // code...
       $id=$_POST['id'];
       $image=$_POST['image'];
       $room_status=$_POST['room_status'];
       $price=$_POST['price'];
      $data = mysqli_query($conn, "SELECT * FROM `room`");

        if (mysqli_num_rows($data) > 0) {
           // code...
         header("location: reserved.php");
        }
        

  }
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>receptionist page</title>
</head>
<body>
   <style>
      .dashName{
         text-align: center;
      }
      
      .room{
         float: left;
         margin-left: 10%;
      }
      .reservedRoom{
         float: right;
         margin-right: 20%;
      }
      img{
         height: 120px;
         width: 120px;
      }
      .btn{
         margin-bottom: 10px;
         background: green;
         width: 110px;
         color:white;
         border: none;
      }

   </style>
 
<div class="container">
   

   <div class="dashName" ><h1>RECEPTIONIST DASHBOARD</h1></div>

   <div class="room">
      <h1 class="roomName">Room Vacating</h1>

      <div class="box-container">
         <?php
            $room_data = mysqli_query($conn, "SELECT * FROM `room` ");
            if(mysqli_num_rows($room_data) > 0){
               while($data = mysqli_fetch_assoc($room_data)){
         ?>
         <form method="post" class="box" action="">
            
            <img src="image/<?php echo $data['image']; ?>" name="image" alt=""><br>
            <?php echo $data['room_status']; ?><br>
            <?php echo $data['price']; ?>/-<br>
            <input type="submit" value="Book" name="Book" class="btn">

         </form>
         <?php
               }
            };
         ?>
      </div>
   </div>

   

     
</div>
</body>
</html>
