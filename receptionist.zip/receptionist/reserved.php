<?php 

  include 'config.php';
  $sql = "SELECT * FROM room";
  $result = $conn->query($sql);
  


 ?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reserved</title>
</head>
<body>
    <div class="reservedRoom">
      <h1 class="roomName">Reserved Room</h1>
   
   <section>
   <table>

      <thead>
         <th>Room Id</th>
         <th>Image</th>
         <th>Room_status</th>
         <th>Room_price</th>
         <th>Action</th>
      </thead>

      <tbody>

         <?php 
         
        
          $select = mysqli_query($conn, "SELECT * FROM `room`");
           if (mysqli_num_rows($select) > 0) {
           while ($data = mysqli_fetch_assoc($select)) {
           ?>
        <tr>
            <td><?php echo $data["id"]; ?></td> 
            <td><img src="image/<?php echo $data['image']; ?>" height="100" alt=""></td>
            <td><?php echo $data['room_status']; ?></td>
            <td>$<?php echo $data['price']; ?>/-</td>

                

           <td><a href="delete.php?id='<?php echo $data["id"]; ?>'"><button>Remove</button></a></td>
          
            
        </tr>
<?php
    } 
};
?>

             <a href="index.php"><button>Back</button></a>

      </tbody>

   </table>

   

</section>
</body>
</html>