<?php 

   include 'config.php';

   
   if (isset($_GET['id'])) {
   
    $id=$_GET['id'];
   $sql = "DELETE FROM room where id=$id ";
    $conn->query($sql);
   }

   header("location: reserved.php");



 ?>