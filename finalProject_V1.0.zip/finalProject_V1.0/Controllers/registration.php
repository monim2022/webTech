<?php
require_once('../Models/allDatabase.php');


if(isset($_POST['submit'])) {
   $name =  $_POST['name'];
   $email =  $_POST['email'];
   $password =  $_POST['password'];
   
   $regiData = registration( $name,$email, $password);
   
   if ($regiData) {
        header('Location: ../Views/home.php');
        echo "Registration successful!";
   } else {
      echo "Registration failed!";
   }
}
?>
