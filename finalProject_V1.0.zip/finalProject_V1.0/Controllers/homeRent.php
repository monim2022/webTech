<?php
require_once('../Models/allDatabase.php');

if(isset($_POST['Book']))
{
    $room_status = $_POST['room_status'];
    $price = $_POST['price'];
    $image = $_POST['image'];


    $roomResult = roomBook($room_status, $price, $image);
    if ($roomResult) {
        header('Location: ../Views/homeRent.php');
    } else {
        echo "Error while booking the room.";
    }
}

if (isset($_GET['delete'])) {
   
    $id=$_GET['delete'];
    $delResult = roomDelete($id);
    if ($delResult) {
        header('Location: ../Views/homeRent.php');

    } else {
        echo "Error while deleting room.";
    }
}




?>
