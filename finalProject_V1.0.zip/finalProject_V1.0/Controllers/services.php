<?php
require_once('../Models/allDatabase.php');

if (isset($_POST['homeRent'])) {
    header('location:../Views/homeRent.php');
} elseif (isset($_POST['foodServ'])) {
    header('location:../Views/foods.php');
} else {
    header('location:../Views/services.php');
}
?>
