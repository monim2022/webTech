<?php 

require_once('../Models/allDatabase.php');

if(isset($_POST['order']))
{
    $name = $_POST['name'];
    $price = $_POST['price'];
    $image = $_POST['image'];
    $quantity = $_POST['quantity'];


    $orderResult = foodOrdered($name, $price, $image,$quantity);
    if ($orderResult) {
        header('Location: ../Views/foods.php');
    } else {
        echo "Error while ordering the food.";
    }
}

if (isset($_GET['delete'])) {
   
    $id=$_GET['delete'];
    $delResult = foodDelete($id);
    if ($delResult) {
        echo "Items successfully deleted!";
        header('Location: ../Views/foods.php');

    } else {
        echo "Error while deleting food items.";
    }
}

if ($_GET['edit']) {
    // code...
    $id = $_GET['edit'];
    $quantity = $_GET['quantity'];
    $updateData = foodUpdate($id,$quantity);
    if ($updateData ) {
        // code...
         echo "Items successfully updated";
        header('Location: ../Views/foods.php');
    }
    else {
        echo "Error while updating food items.";
    }
}



?>
