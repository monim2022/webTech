
<?php
   function getConnection()
   {
   	$server="localhost";
   	$username="root";
   	$password="";
   	$dbName="myPart";
   	$conn= new mysqli($server,$username,$password,$dbName);
   	return $conn; 
   }
?>