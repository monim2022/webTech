<?php
require_once('dataBase.php');

function auth($email, $password)
{
    $conn = getConnection();
    $sql = "SELECT * FROM `user_form` WHERE email = '$email' AND password = '$password'";
    $data = mysqli_query($conn, $sql);

    $count = mysqli_num_rows($data);
    if ($count == 1) {
        return true;
    } else {
        return false;
    }
}

function registration($name, $email, $pass) {
    $conn = getConnection();
     $sql = "INSERT INTO `user_form`(name, email, password) VALUES('$name', '$email', '$pass')" ; 
     $regiQuery = mysqli_query($conn, $sql);
     if ($regiQuery) {
                        
                        return  $regiQuery;
                         } 
                 else {
                       echo "Error";
                      }
   
       
    }

function foodsService()
{
    $conn = getConnection();
    $sql = "SELECT * FROM `foods`";
    $result = mysqli_query($conn, $sql);

    if ($result) {
        return $result;
    } else {
        echo "Error";
    }
}

function foodOrdered($name, $price, $image,$quantity) {
    $conn = getConnection();
$sql = "INSERT INTO `food_cart`(name, price, image, quantity) VALUES('$name', '$price', '$image','$quantity')" ;    
$foods_query = mysqli_query($conn, $sql);
             if ($foods_query) {
                        
                        return  $foods_query;
                         } 
                 else {
                       echo "Error";
                      }


}

function orderList()
{
    $conn = getConnection();
    $sql = "SELECT * FROM `food_cart`";
    $order_data = mysqli_query($conn, $sql);

    if ($order_data) {
        return $order_data;
    } else {
        echo "Error";
    }


}



function homeRent()

{              
               $conn = getConnection();
               $sql = "SELECT * FROM rom";
               $query = mysqli_query($conn, $sql);
                if ($query) {
                        
                        return $query;
                          } 
                else {
                          echo "Error";
                     }
}



function roomBook($room_status, $price, $image) {
    $conn = getConnection();
$sql = "INSERT INTO `reservedroom`(room_status, price, image) VALUES( '$room_status', '$price', '$image')" ;    
$room_query = mysqli_query($conn, $sql);
    if ($room_query) {
                        
                        return  $room_query;
                } 
     else {
            echo "Error";
         }


}
function reservedRoom(){
     $conn = getConnection();
    $sql = "SELECT * FROM `reservedroom`";
    $reserved_data = mysqli_query($conn, $sql);

    if ($reserved_data) {
        return $reserved_data;
    } else {
        echo "Error";
    }

}
function roomDelete($id){
         $conn = getConnection();
         
        $sql = "DELETE FROM `reservedroom` where id=$id ";
        $homeDel = mysqli_query($conn, $sql);
        if ($homeDel) {
            // code...
            return true;
        }
        else false;
          

   }

function foodDelete($id){
         $conn = getConnection();
         
        $sql = "DELETE FROM `food_cart` where id=$id ";
        $foodDel = mysqli_query($conn, $sql);
        if ($foodDel) {
            // code...
            return true;
        }
        else false;
          

   }
   function foodUpdate($id,$quantity)
   {
    $conn = getConnection();
    $sql= "UPDATE `food_cart` SET quantity = '$quantity'  WHERE id = '$id' ; ";
    $updateFood = mysqli_query($conn, $sql);
     if ( $updateFood ) {
         // code...
        return true;
     }
     else false;
   }






 




?>
