<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>services</title>
    <link rel="stylesheet" href="..//cssFiles/services.css">
	</head>
<body>

	   <form action="../Controllers/services.php" method="post">
		
		<div class="mainContainer">

		<h1 class="serviceName">Our Services</h1>
		<hr>
		<div class="cardRent" >
			<button name="homeRent"><h1>HOME RENT</h1></button>
		</div>
		<div class="cardFood" >
			<button name="foodServ"><h1>FOOD SERVICES</h1></button>
		</div>

         	<div class="vl"></div>	
         	
		</div>
		
        

</form>

</body>

</html>