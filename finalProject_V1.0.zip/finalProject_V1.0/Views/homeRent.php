<?php

require_once('../Models/allDatabase.php');

$roomRent = homeRent();
$roomResult = reservedRoom();


?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Home</title>
          <link rel="stylesheet" href="..//cssFiles//homeRent.css">

   <style>
     
                 .reservedRoom img{
                    height: 90px;
                     width: 100px;
                       }
 
                .checkoutBtn{
                    background: green;
                    color: white;
                    border: none;
                    height: 35px;
                    width: 100%; 
                    margin-top: 80%;
                                                
                }
                .payment{
                    display: grid;
                    height: 35px;
                    background: red;
                    width: 100%;
                    text-align: center;
                    color: white;
                    margin-top: 10px;
                }
                .payment h3{
                    margin-top: 5px;
                }
                .aboutUs{
                  margin: 10px;
                  display: grid;
                  grid-template-columns: repeat(5, 1fr);
                  grid-template-rows: repeat(1, 1fr);
                  column-gap: 5px;

            }
            .aboutInfo{
                 background: #2f2f2f;
                 color: white;
                 margin-top: 10px;
                 height: 150px;
            }
            .aboutInfo h3{
                margin-top: 10px;
            }
            .contactUs{
                 background: #828282;
                 color: white;
                 height: 180px;
                 border-radius: 14px;
            }
            .contactUs h4{
                margin-top: 15px;
            }
            .contactUs input{
                margin: 5px;
                height: 20px;
                width: 200px;
            }
             .contactUs button{
                height: 22px;
                width: 70px;
             }
             .contactUs textarea{
                height: 35px;
                width: 200px;
             }
   </style>
</head>
<body>
   <form action="../Controllers/homeRent.php" method="post">

      <div class="mainContainer">
         <div class="header">
          <button class="backBtn"><a href="services.php">Back</a></button>
         <img class="homeImg" src="../images/homReg.png"  height="90px" width="120px">

         </div>
         
         <hr>
         <div class="subContainer">


                
            <?php  
            while ($data = mysqli_fetch_assoc($roomRent)) {
                ?>
                <div class="roomItems">
               <img src="../images/<?php echo $data['image']; ?>" alt="">
          <input type="text" name="room_status" value="<?php echo $data['room_status']?>">
            <input type="text" name="price" value="<?php echo $data['price'] ?>">
               <input type="text" name="image" value="<?php echo $data['image'] ?>" hidden>
             <input type="text" name="id" value="<?php echo $data['id'] ?>" hidden>         
               <input type="submit" value="Book" name="Book" class="btn">

               </div>
           
            <?php
               };?>
                    
         </div>
       </form> 


            <form action="../Controllers/homeRent.php" method="get">

        <div class="reservedRoom">
         <h3>YOUR RESERVED ROOM</h3>
           <table>
              <tr>
                 <th>Image</th>
                 <th>Room Status</th>
                 <th>Price</th>
                 <th colspan="2">Action</th>

              </tr>

              <?php  
                  $total = 0;
                  while ($reservedData = mysqli_fetch_assoc($roomResult)) {
                  
                 $total += $reservedData['price'];
                     ?>
                      <tr>
                        
               <td><img src="../images/<?php echo $reservedData['image']; ?>" alt=""></td>
                        <td><?php echo $reservedData['room_status']; ?></td>
                        <td><?php echo $reservedData['price']; ?></td>
                          <td>
                     <button class="upBtn" name="edit" value="<?php echo $reservedData['id'] ?>">Reserved</button>
                    </td>
                    <td>
                    <button class="delBtn" name="delete" value="<?php echo $reservedData['id'] ?>">Cancel</button>
                    </td>
                  

                      </tr>

              <?php
               };?>


           </table>
 <div class="payment">
    <h3><?php echo "Total Payment:" .$total ?></h3>
 </div>
<button class="checkoutBtn">PROCEED TO CHECKOUT</button> 
        </div>
       </form>

     


      <div class="footer">
            <h2>ABOUT US</h2>
            <hr>
           <div class="aboutUs">
                <div class="aboutInfo">
                    <h3>CEO</h3>
                    <h4>Monim Mia</h4>
                    <span>Student of CSE Department.</span>
                    <span>American International University-Bangadesh</span>
                    <span>Contact:pentheratigries2020@gmail.com</span>

                </div>
                <div class="aboutInfo">
                    <h3>ADMIN</h3>
                    <h4>Asif Chowdhury</h4>
                    <span>Student of CSE Department.</span>
                    <span>American International University-Bangadesh</span>
                    <span>Contact:tipaiexpert@gmail.com</span>
                </div>
                <div class="aboutInfo">
                    <h3>RECIPTIONIST</h3>
                    <h4>Raduanul Islam</h4>
                    <span>Student of CSE Department.</span>
                    <span>American International University-Bangadesh</span>
                    <span>Contact:radu@gmail.com</span>
                </div>
                <div class="aboutInfo">
                    <h3>MANAGER</h3>
                    <h4>Athoy Kana Roy</h4>
                    <span>Student of CSE Department.</span>
                    <span>American International University-Bangadesh</span>
                    <span>Contact:athoykana@gmail.com</span>
                </div>

               <div class="contactUs">
                <form action="">
                    <h4>CONTACT US</h4>
                   <input id="yourMail" type="text" placeholder="Enter your email"><br>
                   <input id="toMail" type="text" placeholder="Enter sender email"><br>
                   <textarea name="" id=""> </textarea><br>
                   <button>Submit</button>
                 </form>
          
             </div> 
           </div>
       </div>


</div>
</body>
</html>
