
<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>register</title>

   <link rel="stylesheet" href="..//cssFiles/register.css">

</head>
<body>
               <h1 class="webName">MyHome</h1>



   <form action="../Controllers/registration.php" method="post" >

      

      <div class="subForm"> 

            <img src="../images/imgr.png" alt="" height="120px" width="120px">
            <h1>Register now</h1>
 
      <input type="text" name="name" placeholder="enter username" class="box" required>
      <input type="email" name="email" placeholder="enter email" class="box" required>
      <input type="password" name="password" placeholder="enter password" class="box" required>
      <input type="password" name="cpassword" placeholder="confirm password" class="box" required>
      <input type="file" name="image" class="box" accept="image/jpg, image/jpeg, image/png">
      <input type="submit" name="submit" value="Register now" class="btn">
      <p>already have an account? <a href="login.php">login now</a></p>
      </div>




   </form>






</body>
</html>