<?php 
    require_once('../Models/allDatabase.php');
    $result = foodsService(); 
    $order_result = orderList();
    


 ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>foods</title>

       <link rel="stylesheet" href="..//cssFiles/foods.css">
       <style>
           .orderList .actionBtn{
                         background: red;

                }
                .orderList .quantityClass{
                    width: 30px;
                }
                .checkoutBtn{
                    background: green;
                    color: white;
                    border: none;
                    height: 35px;
                    width: 100%; 
                    margin-top: 80%;
                                                
                }
                .payment{
                    display: grid;
                    height: 35px;
                    background: red;
                    width: 100%;
                    text-align: center;
                    color: white;
                    margin-top: 10px;
                }
                .payment h3{
                    margin-top: 5px;
                }

                .aboutUs{
                  margin: 10px;
                  display: grid;
                  grid-template-columns: repeat(5, 1fr);
                  grid-template-rows: repeat(1, 1fr);
                  column-gap: 5px;

            }
            .aboutInfo{
                 background: #2f2f2f;
                 color: white;
                 margin-top: 10px;
                 height: 150px;
            }
            .aboutInfo h3{
                margin-top: 10px;
            }
            .contactUs{
                 background: #828282;
                 color: white;
                 height: 180px;
                 border-radius: 14px;
            }
            .contactUs h4{
                margin-top: 15px;
            }
            .contactUs input{
                margin: 5px;
                height: 20px;
                width: 200px;
            }
             .contactUs button{
                height: 22px;
                width: 70px;
             }
             .contactUs textarea{
                height: 35px;
                width: 200px;
             }
       </style>

</head>

<body>

    <div class="container">


        <div class="header">
                <button class="backBtn"><a href="services.php">Back</a></button>
                <h1>MyHome</h1>  
        </div>


            <div class="foods">
                <h2 class="heading">CHOOSE YOUR FOODS</h2>
                <div class="boxContainer">
                <?php  
                   while ($data = mysqli_fetch_assoc($result)) {
                ?>
                        <form method="post" action="../Controllers/foods.php">
                            <div class="foodItems">
                                <img src="../images/<?php echo $data['image']; ?>" alt="">
                                <div class="name"><?php echo $data['name']; ?></div>
                                <div class="price"><?php echo $data['price']; ?>/-</div>
                                <input class="quantity" type="number" min="1" name="quantity" value="1">
                    <input type="text" name="id" value="<?php echo $data['id'] ?>" hidden>         
                                <input type="hidden" name="image" value="<?php echo $data['image']; ?>">
                                <input type="hidden" name="name" value="<?php echo $data['name']; ?>">
                                <input type="hidden" name="price" value="<?php echo $data['price']; ?>">
                                <input type="submit" value="Order" name="order" class="btn">
                            </div>
                        </form>
                <?php
                    };?>
                </div>
            </div>


            <form action="../Controllers/foods.php" method="get">

            <div class="orderList">
                 <h2>YOUR SELECTED ITEMS</h2>
                 <table>
                     <tr>
                         <th>Images</th>
                         <th>Name</th>
                         <th>Quantity</th>
                         <th >Price</th>
                         <th class="actionBtn" colspan="4">Actions</th>
                     </tr> 

                <?php 
                 $total = 0;
                 while ($order_data = mysqli_fetch_assoc($order_result)) {
                    $sub_total = ((int)$order_data['price'] * (int)$order_data['quantity']);
                  $total += $sub_total;
                ?>

                <tr>
               <td><img src="../images/<?php echo $order_data['image']; ?>" alt=""></td>
                    
                    <td><?php  echo $order_data['name']?></td>
                    <td>
    <input type="number" class="quantityClass" name="quantity" value="<?php  echo $order_data['quantity']?>">
                  </td>
                    <td><?php  echo $order_data['price']?></td>
                    <td>
                    <?php echo $sub_total?>Tk
                   </td>
                      <td>
                     <button class="upBtn" name="edit" value="<?php  echo $order_data['id']?>">UPDATE</button>
                    </td>
                    <td>
                    <button class="delBtn" name="delete" value="<?php  echo $order_data['id']?>">DELETE</button>
                    </td>  

                </tr>
                

                <?php } ?>

                 </table>
                 <div class="payment"><h3><?php echo "Total Payment:" .$total ?>  
                        </h3></div>
              <button class="checkoutBtn">PROCEED TO CHECKOUT</button>
            </div>
           </form>

       <div class="footer">
            <h2>ABOUT US</h2>
            <hr>
           <div class="aboutUs">
                <div class="aboutInfo">
                    <h3>CEO</h3>
                    <h4>Monim Mia</h4>
                    <span>Student of CSE Department.</span>
                    <span>American International University-Bangadesh</span>
                    <span>Contact:pentheratigries2020@gmail.com</span>

                </div>
                <div class="aboutInfo">
                    <h3>ADMIN</h3>
                    <h4>Asif Chowdhury</h4>
                    <span>Student of CSE Department.</span>
                    <span>American International University-Bangadesh</span>
                    <span>Contact:tipaiexpert@gmail.com</span>
                </div>
                <div class="aboutInfo">
                    <h3>RECIPTIONIST</h3>
                    <h4>Raduanul Islam</h4>
                    <span>Student of CSE Department.</span>
                    <span>American International University-Bangadesh</span>
                    <span>Contact:radu@gmail.com</span>
                </div>
                <div class="aboutInfo">
                    <h3>MANAGER</h3>
                    <h4>Athoy Kana Roy</h4>
                    <span>Student of CSE Department.</span>
                    <span>American International University-Bangadesh</span>
                    <span>Contact:athoykana@gmail.com</span>
                </div>

               <div class="contactUs">
                <form action="">
                    <h4>CONTACT US</h4>
                   <input id="yourMail" type="text" placeholder="Enter your email"><br>
                   <input id="toMail" type="text" placeholder="Enter sender email"><br>
                   <textarea name="" id=""> </textarea><br>
                   <button>Submit</button>
                 </form>
               </div>
           </div>
       </div>


    </div>
</body>
</html>
