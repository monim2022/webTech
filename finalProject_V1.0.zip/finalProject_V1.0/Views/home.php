<?php 
    // Initialize variables
require_once('../Models/allDatabase.php');

$errorEmail = $errorPass = $errorEmPass = ""; 

if (isset($_POST['submit'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    if ($email == "" && $password == "") {
        $errorEmPass = "Email and Password are required";
    } elseif ($email == "") {
        $errorEmail = "Email is required";
    } elseif ($password == "") {
        $errorPass = "Password is required";
    } else {
        $status = auth($email, $password);
        if ($status) {
            header('location:../Views/services.php');
            exit(); 
        } else {
            $errorEmail = "Invalid credentials";
        }
    }
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>login</title>
    <link rel="stylesheet" href="../cssFiles/login.css">
</head>
<body>
    <h1 class="webName">MyHome</h1>
    <form action="" method="post">
        <div class="subForm">
            <img src="../images/house.png" alt="" height="100px" width="100px">
            <h1>Login Now</h1>
            <input type="email" name="email" placeholder="Enter email" class="box"><br>
            <span><?php echo $errorEmail; ?></span>
            <input type="password" name="password" placeholder="Enter password" class="box"><br>
             <span><?php echo $errorPass; ?></span>
              <span><?php echo $errorEmPass; ?></span>

            <input type="submit" name="submit" value="login now" class="btn">
            <p>don't have an account? <a href="register.php">register now</a></p>
        </div>
    </form>
</body>
</html>
