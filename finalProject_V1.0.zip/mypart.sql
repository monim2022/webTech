-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 28, 2023 at 07:19 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mypart`
--

-- --------------------------------------------------------

--
-- Table structure for table `foods`
--

CREATE TABLE `foods` (
  `id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `price` varchar(100) NOT NULL,
  `image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `foods`
--

INSERT INTO `foods` (`id`, `name`, `price`, `image`) VALUES
(7, 'rice', '20Tk', 'rice.jpeg'),
(8, 'Bread', '10Tk', 'bread.jpeg'),
(11, 'rice', '30Tk', 'rice.jpeg'),
(12, 'Bread', '50Tk', 'bread.jpeg'),
(13, 'rice', '30Tk', 'rice.jpeg'),
(15, 'Mutton Curry', '250Tk', 'mutton.jpeg'),
(16, 'Break Fast', '150Tk', 'imgFour.jpeg'),
(17, 'Mutton Curry', '250Tk', 'mutton.jpeg'),
(19, 'Bread', '50Tk', 'imgThree.jpeg'),
(20, 'Mutton', '250Tk', 'mutton.jpeg'),
(21, 'Bread', '50Tk', 'imgThree.jpeg'),
(22, 'Mutton', '250Tk', 'mutton.jpeg'),
(23, 'Kacci Biryani', '350TK', 'kacci.jpeg'),
(24, 'Fish Biryani', '250Tk', 'fishBiryani.jpg'),
(25, 'Kacci Biryani', '350TK', 'kacci.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `food_cart`
--

CREATE TABLE `food_cart` (
  `id` int(100) NOT NULL,
  `user_id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `price` varchar(100) NOT NULL,
  `image` varchar(100) NOT NULL,
  `quantity` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `food_cart`
--

INSERT INTO `food_cart` (`id`, `user_id`, `name`, `price`, `image`, `quantity`) VALUES
(31, 0, 'rice', '30Tk', 'rice.jpeg', 3);

-- --------------------------------------------------------

--
-- Table structure for table `reservedroom`
--

CREATE TABLE `reservedroom` (
  `id` int(11) NOT NULL,
  `room_status` varchar(255) NOT NULL,
  `price` int(255) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reservedroom`
--

INSERT INTO `reservedroom` (`id`, `room_status`, `price`, `image`) VALUES
(5, '5beds', 50000, 'roomFour.jpeg'),
(12, '5beds', 50000, 'roomFour.jpeg'),
(14, '5beds', 50000, 'roomFour.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `rom`
--

CREATE TABLE `rom` (
  `id` int(11) NOT NULL,
  `image` varchar(255) NOT NULL,
  `room_status` varchar(50) NOT NULL,
  `price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rom`
--

INSERT INTO `rom` (`id`, `image`, `room_status`, `price`) VALUES
(1, 'roomOne.jpeg', '3beds', 30000.00),
(2, 'roomTwo.jpeg', '3beds', 40000.00),
(3, 'roomOne.jpeg', '3beds', 30000.00),
(4, 'roomTwo.jpeg', '3beds', 40000.00),
(5, 'roomThree.jpeg', '4beds', 40000.00),
(6, 'roomFour.jpeg', '5beds', 50000.00),
(7, 'roomThree.jpeg', '4beds', 40000.00),
(8, 'roomFour.jpeg', '5beds', 50000.00);

-- --------------------------------------------------------

--
-- Table structure for table `user_form`
--

CREATE TABLE `user_form` (
  `id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_form`
--

INSERT INTO `user_form` (`id`, `name`, `email`, `password`, `image`) VALUES
(8, 'monim', 'asdf@gmail.com', '12345', ''),
(10, 'miamonim', 'miamonim@gmail.com', '12345678', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `foods`
--
ALTER TABLE `foods`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `food_cart`
--
ALTER TABLE `food_cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reservedroom`
--
ALTER TABLE `reservedroom`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rom`
--
ALTER TABLE `rom`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_form`
--
ALTER TABLE `user_form`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `foods`
--
ALTER TABLE `foods`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `food_cart`
--
ALTER TABLE `food_cart`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `reservedroom`
--
ALTER TABLE `reservedroom`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `rom`
--
ALTER TABLE `rom`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `user_form`
--
ALTER TABLE `user_form`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
