<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>My Home</title>
    <style>
        a {
            float: right;
            
            
        }
        .container{
            background: black;
            color: white;
        }

       
        
    </style>
</head>
<body>
    <div class="container">
        <header>
            <fieldset>
                <h3>MyHome</h3>
                <a href="./View/login.php" class="btn btn-outline-primary">Login</a>
            </fieldset>
        </header>
        <div align="center" class="content">
            <h4>Welcome to MyHome Project</h4>
        </div>
    </div>
</body>
</html>